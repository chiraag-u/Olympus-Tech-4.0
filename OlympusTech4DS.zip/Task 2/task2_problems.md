## Q1. How does the recorded primary hazard relate to a planet's settlement potential?

Which hazards are associated with higher or lower settlement scores?


## Q2. How do atmospheric gas levels relate to settlement potential?

Investigate how the recorded percentages of oxygen (oxygen_percent), carbon dioxide (co2_percent), and methane (methane_percent) relate to settlement_index.


## Q3. How does stellar multiplicity relate to settlement potential?

Investigate whether planets associated with single-star, binary-star, triple-star, or other multiple-star systems differ in their settlement_index.


## Q4. How do the number of moons and the presence of rings relate to settlement potential?

Explore the relationship between moons_count, rings, and settlement_index.


## Q5. How do rogue planets and tidally locked planets compare with other planets in settlement potential?

Investigate how settlement_index differs between planets labelled as rogue planets, tidally locked planets, and those without either label.